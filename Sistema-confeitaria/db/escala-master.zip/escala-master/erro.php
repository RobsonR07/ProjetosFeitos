<?php 

echo "acesso negado !!!"; ?>